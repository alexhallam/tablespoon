__version__ = '0.1.0'

import pkgutil

from .forecasters import Mean, Naive, Snaive
